--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE booking;
--
-- Name: booking; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE booking WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE booking OWNER TO postgres;

\connect booking

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: checkCredentials(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public."checkCredentials"(username character varying, pass character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$declare
	us record;
begin
	for us in select user_id
	from users
	loop
		if us.user_id = username then
			return true;
		end if;
	end loop;
	
	return false;
end;


$$;


ALTER FUNCTION public."checkCredentials"(username character varying, pass character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.properties (
    property_id integer NOT NULL,
    property_name character varying(100) NOT NULL,
    description character varying(10000),
    rating numeric,
    city_id integer NOT NULL,
    property_type integer NOT NULL,
    CONSTRAINT property_type_check CHECK (((property_type = 1) OR (property_type = 2)))
);


ALTER TABLE public.properties OWNER TO postgres;

--
-- Name: Properties_property_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Properties_property_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Properties_property_id_seq" OWNER TO postgres;

--
-- Name: Properties_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Properties_property_id_seq" OWNED BY public.properties.property_id;


--
-- Name: car_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.car_booking (
    booking_id integer NOT NULL,
    user_id character varying NOT NULL,
    car_id integer NOT NULL,
    pick_up_location character varying NOT NULL,
    drop_off_location character varying NOT NULL,
    pick_up_date date NOT NULL,
    drop_off_date date NOT NULL,
    driver_age integer,
    price integer
);


ALTER TABLE public.car_booking OWNER TO postgres;

--
-- Name: car_booking_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.car_booking_booking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.car_booking_booking_id_seq OWNER TO postgres;

--
-- Name: car_booking_booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.car_booking_booking_id_seq OWNED BY public.car_booking.booking_id;


--
-- Name: car_booking_car_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.car_booking_car_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.car_booking_car_id_seq OWNER TO postgres;

--
-- Name: car_booking_car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.car_booking_car_id_seq OWNED BY public.car_booking.car_id;


--
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    car_id integer NOT NULL,
    property_id integer NOT NULL,
    price integer NOT NULL,
    seats integer,
    gearbox character varying(30),
    air_conditioned boolean,
    large_bags integer,
    doors integer,
    latest_booking_id integer
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- Name: cars_car_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cars_car_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cars_car_id_seq OWNER TO postgres;

--
-- Name: cars_car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cars_car_id_seq OWNED BY public.cars.car_id;


--
-- Name: cars_property_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cars_property_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cars_property_id_seq OWNER TO postgres;

--
-- Name: cars_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cars_property_id_seq OWNED BY public.cars.property_id;


--
-- Name: cities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cities (
    city_id integer NOT NULL,
    city_name character varying(30) NOT NULL
);


ALTER TABLE public.cities OWNER TO postgres;

--
-- Name: TABLE cities; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.cities IS 'Contains information about cities.';


--
-- Name: cities_city_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cities_city_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cities_city_id_seq OWNER TO postgres;

--
-- Name: cities_city_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cities_city_id_seq OWNED BY public.cities.city_id;


--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    review_id integer NOT NULL,
    user_id character varying NOT NULL,
    property_id integer NOT NULL,
    review_description character varying(10000),
    rating real NOT NULL
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: review_property_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_property_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_property_id_seq OWNER TO postgres;

--
-- Name: review_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_property_id_seq OWNED BY public.review.property_id;


--
-- Name: review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_review_id_seq OWNER TO postgres;

--
-- Name: review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_review_id_seq OWNED BY public.review.review_id;


--
-- Name: room_booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_booking (
    booking_id integer NOT NULL,
    user_id character varying(30) NOT NULL,
    room_id integer NOT NULL,
    check_in_date date NOT NULL,
    check_out_date date NOT NULL,
    number_of_persons integer,
    price integer NOT NULL
);


ALTER TABLE public.room_booking OWNER TO postgres;

--
-- Name: room_booking_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_booking_booking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.room_booking_booking_id_seq OWNER TO postgres;

--
-- Name: room_booking_booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.room_booking_booking_id_seq OWNED BY public.room_booking.booking_id;


--
-- Name: room_booking_room_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_booking_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.room_booking_room_id_seq OWNER TO postgres;

--
-- Name: room_booking_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.room_booking_room_id_seq OWNED BY public.room_booking.room_id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    room_id integer NOT NULL,
    property_id integer NOT NULL,
    price integer NOT NULL,
    room_type character varying(100),
    air_conditioned boolean,
    sleeps integer,
    room_description character varying(10000),
    latest_booking_id integer
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_property_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_property_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rooms_property_id_seq OWNER TO postgres;

--
-- Name: rooms_property_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_property_id_seq OWNED BY public.rooms.property_id;


--
-- Name: rooms_room_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rooms_room_id_seq OWNER TO postgres;

--
-- Name: rooms_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_room_id_seq OWNED BY public.rooms.room_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id character varying(30) NOT NULL,
    name character varying(50),
    mobile_no character varying(15),
    email_id character varying(50) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: car_booking booking_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_booking ALTER COLUMN booking_id SET DEFAULT nextval('public.car_booking_booking_id_seq'::regclass);


--
-- Name: car_booking car_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_booking ALTER COLUMN car_id SET DEFAULT nextval('public.car_booking_car_id_seq'::regclass);


--
-- Name: cars car_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars ALTER COLUMN car_id SET DEFAULT nextval('public.cars_car_id_seq'::regclass);


--
-- Name: cars property_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars ALTER COLUMN property_id SET DEFAULT nextval('public.cars_property_id_seq'::regclass);


--
-- Name: cities city_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cities ALTER COLUMN city_id SET DEFAULT nextval('public.cities_city_id_seq'::regclass);


--
-- Name: properties property_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties ALTER COLUMN property_id SET DEFAULT nextval('public."Properties_property_id_seq"'::regclass);


--
-- Name: review review_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review ALTER COLUMN review_id SET DEFAULT nextval('public.review_review_id_seq'::regclass);


--
-- Name: review property_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review ALTER COLUMN property_id SET DEFAULT nextval('public.review_property_id_seq'::regclass);


--
-- Name: room_booking booking_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking ALTER COLUMN booking_id SET DEFAULT nextval('public.room_booking_booking_id_seq'::regclass);


--
-- Name: room_booking room_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking ALTER COLUMN room_id SET DEFAULT nextval('public.room_booking_room_id_seq'::regclass);


--
-- Name: rooms room_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN room_id SET DEFAULT nextval('public.rooms_room_id_seq'::regclass);


--
-- Name: rooms property_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN property_id SET DEFAULT nextval('public.rooms_property_id_seq'::regclass);


--
-- Data for Name: car_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.car_booking (booking_id, user_id, car_id, pick_up_location, drop_off_location, pick_up_date, drop_off_date, driver_age, price) FROM stdin;
\.
COPY public.car_booking (booking_id, user_id, car_id, pick_up_location, drop_off_location, pick_up_date, drop_off_date, driver_age, price) FROM '$$PATH$$/2903.dat';

--
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cars (car_id, property_id, price, seats, gearbox, air_conditioned, large_bags, doors, latest_booking_id) FROM stdin;
\.
COPY public.cars (car_id, property_id, price, seats, gearbox, air_conditioned, large_bags, doors, latest_booking_id) FROM '$$PATH$$/2906.dat';

--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cities (city_id, city_name) FROM stdin;
\.
COPY public.cities (city_id, city_name) FROM '$$PATH$$/2909.dat';

--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.properties (property_id, property_name, description, rating, city_id, property_type) FROM stdin;
\.
COPY public.properties (property_id, property_name, description, rating, city_id, property_type) FROM '$$PATH$$/2901.dat';

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review (review_id, user_id, property_id, review_description, rating) FROM stdin;
\.
COPY public.review (review_id, user_id, property_id, review_description, rating) FROM '$$PATH$$/2911.dat';

--
-- Data for Name: room_booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_booking (booking_id, user_id, room_id, check_in_date, check_out_date, number_of_persons, price) FROM stdin;
\.
COPY public.room_booking (booking_id, user_id, room_id, check_in_date, check_out_date, number_of_persons, price) FROM '$$PATH$$/2914.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (room_id, property_id, price, room_type, air_conditioned, sleeps, room_description, latest_booking_id) FROM stdin;
\.
COPY public.rooms (room_id, property_id, price, room_type, air_conditioned, sleeps, room_description, latest_booking_id) FROM '$$PATH$$/2917.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, name, mobile_no, email_id) FROM stdin;
\.
COPY public.users (user_id, name, mobile_no, email_id) FROM '$$PATH$$/2920.dat';

--
-- Name: Properties_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Properties_property_id_seq"', 12, true);


--
-- Name: car_booking_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.car_booking_booking_id_seq', 1, false);


--
-- Name: car_booking_car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.car_booking_car_id_seq', 1, false);


--
-- Name: cars_car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cars_car_id_seq', 1, false);


--
-- Name: cars_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cars_property_id_seq', 1, false);


--
-- Name: cities_city_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cities_city_id_seq', 13, true);


--
-- Name: review_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_property_id_seq', 1, false);


--
-- Name: review_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_review_id_seq', 1, false);


--
-- Name: room_booking_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_booking_booking_id_seq', 1, false);


--
-- Name: room_booking_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_booking_room_id_seq', 1, false);


--
-- Name: rooms_property_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_property_id_seq', 1, false);


--
-- Name: rooms_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_room_id_seq', 2, true);


--
-- Name: properties Properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT "Properties_pkey" PRIMARY KEY (property_id);


--
-- Name: car_booking car_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_booking
    ADD CONSTRAINT car_booking_pkey PRIMARY KEY (booking_id);


--
-- Name: cars cars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT cars_pkey PRIMARY KEY (car_id);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (city_id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (review_id);


--
-- Name: room_booking room_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking
    ADD CONSTRAINT room_booking_pkey PRIMARY KEY (booking_id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (room_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: car_booking car_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_booking
    ADD CONSTRAINT car_id FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- Name: properties city_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT city_id FOREIGN KEY (city_id) REFERENCES public.cities(city_id);


--
-- Name: rooms latest_booking_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT latest_booking_id FOREIGN KEY (latest_booking_id) REFERENCES public.room_booking(booking_id);


--
-- Name: cars latest_booking_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT latest_booking_id FOREIGN KEY (latest_booking_id) REFERENCES public.car_booking(booking_id);


--
-- Name: rooms property_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT property_id FOREIGN KEY (property_id) REFERENCES public.properties(property_id);


--
-- Name: cars property_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT property_id FOREIGN KEY (property_id) REFERENCES public.properties(property_id);


--
-- Name: review property_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT property_id FOREIGN KEY (property_id) REFERENCES public.properties(property_id);


--
-- Name: room_booking room_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking
    ADD CONSTRAINT room_id FOREIGN KEY (room_id) REFERENCES public.rooms(room_id);


--
-- Name: room_booking user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_booking
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: car_booking user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_booking
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: review user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

